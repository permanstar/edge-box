const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const mqtt = require('mqtt');
const fs = require('fs');
const path = require('path');

// Configuration
const PORT = process.env.PORT || 3000;
const MQTT_BROKER_URL = process.env.MQTT_BROKER_URL || 'mqtt://localhost:1883';
const MQTT_TOPIC = process.env.MQTT_TOPIC || 'edge/data';

// Initialize Express app
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Create HTTP server
const server = http.createServer(app);

// Initialize WebSocket server
const wss = new WebSocket.Server({ server });

// Connect to MQTT broker
const mqttClient = mqtt.connect(MQTT_BROKER_URL);

// Store for the latest data
let latestData = {};

// MQTT client setup
mqttClient.on('connect', () => {
  console.log(`Connected to MQTT broker at ${MQTT_BROKER_URL}`);
  mqttClient.subscribe(MQTT_TOPIC, (err) => {
    if (err) {
      console.error('Failed to subscribe to topic:', err);
    } else {
      console.log(`Subscribed to topic: ${MQTT_TOPIC}`);
    }
  });
});

mqttClient.on('message', (topic, message) => {
  try {
    const data = JSON.parse(message.toString());
    latestData = data;
    console.log('Received data from MQTT:', topic);
    
    // Broadcast to all connected WebSocket clients
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(latestData));
      }
    });
  } catch (error) {
    console.error('Error processing MQTT message:', error);
  }
});

// WebSocket connection handling
wss.on('connection', (ws) => {
  console.log('New WebSocket client connected');
  
  // Send the latest data to the newly connected client
  if (Object.keys(latestData).length > 0) {
    ws.send(JSON.stringify(latestData));
  }
});

// API Routes
app.get('/api/data', (req, res) => {
  res.json(latestData);
});

app.get('/api/status', (req, res) => {
  res.json({
    server: 'running',
    mqtt: mqttClient.connected ? 'connected' : 'disconnected',
    wsClients: wss.clients.size
  });
});

// Start the server
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});