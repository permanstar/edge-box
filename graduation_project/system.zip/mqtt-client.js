const mqtt = require('mqtt');
const fs = require('fs');

// Configuration
const MQTT_BROKER_URL = process.env.MQTT_BROKER_URL || 'mqtt://localhost:1883';
const MQTT_TOPIC = process.env.MQTT_TOPIC || 'edge/data';
const DATA_FILE = './data/sensor-data.json';

// Ensure data directory exists
if (!fs.existsSync('./data')) {
  fs.mkdirSync('./data');
}

// Initialize with sample edge box data
const edgeBoxData = {
  timestamp: Date.now(),
  devices: [
    {
      id: 'device-001',
      name: '温度传感器 1',
      type: 'temperature',
      value: 25.5,
      unit: '°C',
      status: 'online'
    },
    {
      id: 'device-002',
      name: '湿度传感器 1',
      type: 'humidity',
      value: 60.2,
      unit: '%',
      status: 'online'
    },
    {
      id: 'device-003',
      name: '光照传感器 1',
      type: 'light',
      value: 450,
      unit: 'lux',
      status: 'online'
    }
  ],
  system: {
    cpu: 35,
    memory: 42,
    storage: 28,
    network: 'connected'
  }
};

// Save initial data
fs.writeFileSync(DATA_FILE, JSON.stringify(edgeBoxData, null, 2));

// Connect to MQTT broker
const client = mqtt.connect(MQTT_BROKER_URL);

client.on('connect', () => {
  console.log(`Connected to MQTT broker at ${MQTT_BROKER_URL}`);
  
  // Simulate sending data periodically
  setInterval(() => {
    // Update with random data to simulate real sensors
    edgeBoxData.timestamp = Date.now();
    edgeBoxData.devices[0].value = (20 + Math.random() * 10).toFixed(1);
    edgeBoxData.devices[1].value = (50 + Math.random() * 30).toFixed(1);
    edgeBoxData.devices[2].value = Math.floor(400 + Math.random() * 200);
    
    edgeBoxData.system.cpu = Math.floor(20 + Math.random() * 60);
    edgeBoxData.system.memory = Math.floor(30 + Math.random() * 50);
    
    // Save to file
    fs.writeFileSync(DATA_FILE, JSON.stringify(edgeBoxData, null, 2));
    
    // Publish to MQTT topic
    client.publish(MQTT_TOPIC, JSON.stringify(edgeBoxData));
    console.log('Published sensor data to MQTT topic');
    
  }, 5000); // Update every 5 seconds
});

client.on('error', (err) => {
  console.error('MQTT client error:', err);
});

// Handle graceful shutdown
process.on('SIGINT', () => {
  client.end();
  console.log('MQTT client disconnected');
  process.exit(0);
});